=========================
Canada Payroll Accounting
=========================
Add the Canada Payroll Journal

Map the salary rules of the Canada payroll structure to accounts of
the Canada account chart.

Contributors
------------
* Pierre Lamarche <pierre.lamarche@savoirfairelinux.com>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* David Dufresne <david.dufresne@savoirfairelinux.com>