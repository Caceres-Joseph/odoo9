=======================
Employee Benefit On Job
=======================

Add the possibility to put employee benefits on the job.
Add employee benefits computed per hour for each job the employee works on.
Each worked days record related to a job will trigger benefits.


Usage
=====

On the jobs related to an employee's contract, add employee benefits.


Credits
=======

Contributors
------------
* David Dufresne <david.dufresne@savoirfairelinux.com>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* Pierre Lamarche <pierre.lamarche@savoirfairelinux.com>
