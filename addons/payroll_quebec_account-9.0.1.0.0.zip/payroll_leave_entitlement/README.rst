.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

=================
Leave Entitlement
=================

This module allowsto define when an employee is authorized to consume
his leaves accruded. For exemple, an employee could be allowed to take
his vacations he accruded the previous year.


Credits
=======

Contributors
------------
* David Dufresne <david.dufresne@savoirfairelinux.com>
