.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License: AGPL-3

HR Employee First Name, Last Name
=================================

This module was forked from hr_employee_firstname on OCA, because the later one
is way too complicate and relies on partner_firtname. The feature is simple, we need 2 simple
fields.


Credits
=======

Contributors
------------

* El Hadji Dem <elhadji.dem@savoirfairelinux.com>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Fekete Mihai <feketemihai@gmail.com>
* David Dufresne <david.dufresne@savoirfairelinux.com>
* Adrien Peiffer (ACSONE) <adrien.peiffer@acsone.eu>

Maintainer
----------

.. image:: http://odoo-community.org/logo.png
   :alt: Odoo Community Association
   :target: http://odoo-community.org

This module is maintained by the OCA.

OCA, or the Odoo Community Association, is a nonprofit organization whose
mission is to support the collaborative development of Odoo features and
promote its widespread use.

To contribute to this module, please visit http://odoo-community.org.
