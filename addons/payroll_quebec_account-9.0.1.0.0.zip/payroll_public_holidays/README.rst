HR Public Holidays
==================

This module is used to manage public holidays.


Configuration
=============

To configure this module, go to the menu *Human Resources > Configuration > Public Holidays* and create one public holiday entry per year and country.


Credits
=======

Contributors
------------

* Michael Telahun Makonnen <mmakonnen@gmail.com>
* Fekete Mihai <feketemihai@gmail.com>
* Nikolina Todorova <nikolina.todorova@initos.com>
* Alexis de Lattre <alexis.delattre@akretion.com>
* David Dufresne <david.dufresne@savoirfairelinux.com>
