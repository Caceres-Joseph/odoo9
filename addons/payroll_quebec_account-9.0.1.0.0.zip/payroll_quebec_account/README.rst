=========================
Quebec Payroll Accounting
=========================
Add the accounting of the Releve 1 summary.

Map the salary rules of the Quebec payroll structure to accounts of
the Canada account chart.

Contributors
------------
* Pierre Lamarche <pierre.lamarche@savoirfairelinux.com>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* David Dufresne <david.dufresne@savoirfairelinux.com>